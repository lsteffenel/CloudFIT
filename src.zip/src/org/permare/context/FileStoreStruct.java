/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.permare.context;

import java.nio.file.FileStore;

/**
 *
 * @author Luiz Angelo STEFFENEL <Luiz-Angelo.Steffenel@univ-reims.fr>
 */
public class FileStoreStruct {

    public double freeSpace;
    public String path;
    public FileStore store;
}
